﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorseConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            Update();
        }
 
   private void textBox2_TextChanged(object sender, EventArgs e)
        {/*
            string converted = textBox2.Text.ToUpper();


            string[] morse = new string[39] { " .- ", " -... ", " -.-. ", " -.. ", " . ", " ..-. ", " --. ", " .... ", " .. ", " .--- ", " -.- ", " .-.. ", " -- ", " -. ", " --- ", " .--. ", " --.- ", " .-. ", " ... ", " - ", " ..- ", " ...- ", " .-- ", " -..- ", " -.-- ", " --.. ", " ----- ", " .---- ", " ..--- ", " ...-- ", " ....- ", " ..... ", " -.... ", " --... ", " ---.. ", " ----. ", " .-.-.- ", " --..-- ", " ..--.. " };
            string[] latin = new string[39] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", ",", "?" };
            for (int i = 0; i < morse.Length; i++)
            {
                converted = converted.Replace(morse[i], latin[i]);
            }

            /*if (checkBox1.Checked)
            {
                converted = converted.Replace(" ", "/");
            }
            textBox1.Text = converted;
 */

        }
   
            private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Update();
        }

        void Update()
        {
            string converted = textBox1.Text.ToUpper();


            string[] morse = new string[39] { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..", "-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----.", ".-.-.-", "--..--", "..--.." };
            string[] latin = new string[39] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", ",", "?" };


            if (checkBox1.Checked)
            {
                converted = converted.Replace(" ", "/");
            }

            for (int i = 0; i < morse.Length; i++)
            {

                converted = converted.Replace(latin[i], " " + morse[i] + " ");
            }

            textBox2.Text = converted;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(textBox2.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        
        }
    }
}
